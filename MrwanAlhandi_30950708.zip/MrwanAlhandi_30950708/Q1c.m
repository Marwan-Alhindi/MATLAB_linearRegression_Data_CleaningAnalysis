% Q1c

% Some code may already be provided below
% DO NOT clear, close or clc inside this script
% Apply good programming practices
%
% Name : Mrwan Alhandi
% ID   : 30950708
% Date Modified : 21/05/2022

fprintf('\n Q1c \n\n')
%% c:
subplot(2,1,1)

%reading image
imageRead = imread("world_map.bmp");

%allocating populatin for each continent
africaPop = 0;
asiaPop = 0;
europePop = 0;
southAmericaPop = 0;
northAmericaPop = 0;
oceaniaPop = 0;

%using logicals to find all the covid data that have a specific continent
asiaLogical = continent == 'Asia';
asiaLocations = location(asiaLogical);
asiaUnique = unique(asiaLocations);
%to make the length of all the continent consistent so that the for loop
%belew can be done
asiaUnique(49:54) = '0';

africaLogical = continent == 'Africa';
africaLocations = location(africaLogical);
africaUnique = unique(africaLocations);

europeLogical = continent == 'Europe';
europeLocations = location(europeLogical);
europeUnique = unique(europeLocations);
europeUnique(46:54) = '0';


southAmericaLogical = continent == 'South America';
southAmericaLocations = location(southAmericaLogical);
southAmericaUnique = unique(southAmericaLocations);
southAmericaUnique(13:54) = '0';


northAmericaLogical = continent == 'North America';
northAmericaLocations = location(northAmericaLogical);
northAmericaUnique = unique(northAmericaLocations);
northAmericaUnique(24:54) = '0';

oceaniaLogical = continent == 'Oceania';
oceaniaLocations = location(oceaniaLogical);
oceaniaUnique = unique(oceaniaLocations);
oceaniaUnique(18:54) = '0';

%this for loop calculate add all the countries population values to its
%corresponding continent
for c = 1:54
    for j = 1:length(uniqueLocations)
        if asiaUnique(c) == uniqueLocations(j)
            asiaPop = asiaPop + valuesPopulation(j);
        elseif africaUnique(c) == uniqueLocations(j)
            africaPop = africaPop + valuesPopulation(j);
        elseif europeUnique(c) == uniqueLocations(j)
            europePop = europePop + valuesPopulation(j);
        elseif southAmericaUnique(c) == uniqueLocations(j)
            southAmericaPop = southAmericaPop + valuesPopulation(j);
        elseif northAmericaUnique(c) == uniqueLocations(j)
            northAmericaPop = northAmericaPop + valuesPopulation(j);
        elseif oceaniaUnique(c) == uniqueLocations(j)
            oceaniaPop = oceaniaPop + valuesPopulation(j);
        end
    end
end

legend('Africa','Asia','Europe','North America','Oceania','South America','Location','best')

%finding the max cases for each continent
maxCasesAfrica = max(totalAccumulatedCases(1,1:end));
maxCasesAsia = max(totalAccumulatedCases(2,1:end));
maxCasesEurope = max(totalAccumulatedCases(3,1:end));
maxCasesNorthAmerica = max(totalAccumulatedCases(4,1:end));
maxCasesOceania= max(totalAccumulatedCases(5,1:end));
maxCasesSouthAmerica = max(totalAccumulatedCases(6,1:end));

%finding the ratio for each continent by dividing the maximum number of
%cases by the continent population
africaRatioCases = maxCasesAfrica/africaPop;
asiaRatioCases = maxCasesAsia/asiaPop;
europeRatioCases = maxCasesEurope/europePop;
northAmericaRatioCases = maxCasesNorthAmerica/northAmericaPop;
oceaniaRatioCases = maxCasesOceania/oceaniaPop;
southAmericaRatioCases = maxCasesSouthAmerica/southAmericaPop;

%concatenating
all_cases_ratios = [africaRatioCases asiaRatioCases europeRatioCases northAmericaRatioCases oceaniaRatioCases southAmericaRatioCases];

%finding the maximum deaths for each continent
maxDeathsAfrica = max(totalAccumulatedDeaths(1,1:end));
maxDeathsAsia = max(totalAccumulatedDeaths(2,1:end));
maxDeathsEurope = max(totalAccumulatedDeaths(3,1:end));
maxDeathsNorthAmerica = max(totalAccumulatedDeaths(4,1:end));
maxDeathsOceania= max(totalAccumulatedDeaths(5,1:end));
maxDeathsSouthAmerica = max(totalAccumulatedDeaths(6,1:end));

%finding the ratio for each continent by dividing the maximum number of
%deaths by the continent population
africaRatioDeaths = maxDeathsAfrica/africaPop;
asiaRatioDeaths = maxDeathsAsia/asiaPop;
europeRatioDeaths = maxDeathsEurope/europePop;
northAmericaRatioDeaths = maxDeathsNorthAmerica/northAmericaPop;
oceaniaRatioDeaths = maxDeathsOceania/oceaniaPop;
southAmericaRatioDeaths = maxDeathsSouthAmerica/southAmericaPop;

%concatenating
all_deaths_ratios = [africaRatioDeaths asiaRatioDeaths europeRatioDeaths northAmericaRatioDeaths oceaniaRatioDeaths southAmericaRatioDeaths];

%calculating the pixel shade for each continent (cases)
pixelShadeCases = zeros(1,6);
for b = 1:length(pixelShadeCases)
    pixelShadeCases(1,b) = (all_cases_ratios(b)*255)/southAmericaRatioCases;
end
%calculating the pixel shade for each continent (deaths)
pixelShadeDeaths = zeros(1,6);
for k = 1:length(pixelShadeDeaths)
    pixelShadeDeaths(1,k) = (all_deaths_ratios(k)*255)/southAmericaRatioDeaths;
end

%this for loop is to create a new image matrix but with updated pixel shade
x = zeros(300,650);
for p = 1:300
    for o = 1:650

        if imageRead(p,o) == 4 %south america
            x(p,o) =  pixelShadeCases(6);
        elseif imageRead(p,o) == 5 % northen america
            x(p,o) = pixelShadeCases(4);
        elseif imageRead(p,o) == 3 %europe
            x(p,o) = pixelShadeCases(3);
        elseif imageRead(p,o) == 2 %asia
            x(p,o) = pixelShadeCases(2);
        elseif imageRead(p,o) == 1 %africa
            x(p,o) = pixelShadeCases(1);
        elseif imageRead(p,o) == 6 %oceania
            x(p,o) = pixelShadeCases(5);
        elseif imageRead(p,o) == 0 %background
            x(p,o) = 100;
        end

    end
end

imshow(x,[])
xlabel('cases per million population')

%similar approach but for deaths
y = zeros(300,650);
for p = 1:300
    for o = 1:650

        if imageRead(p,o) == 4
            y(p,o) = pixelShadeDeaths(6);
        elseif imageRead(p,o) == 5
            y(p,o) = pixelShadeDeaths(4);
        elseif imageRead(p,o) == 3
            y(p,o) = pixelShadeDeaths(3);
        elseif imageRead(p,o) == 2
            y(p,o) = pixelShadeDeaths(2);
        elseif imageRead(p,o) == 1
            y(p,o) = pixelShadeDeaths(1);
        elseif imageRead(p,o) == 6
            y(p,o) = pixelShadeDeaths(5);
        elseif imageRead(p,o) == 0
            y(p,o) = 100;
        end

    end
end

subplot(2,1,2)
imshow(y,[])
xlabel('deaths per million population')
all_cases_ratios = [africaRatioCases asiaRatioCases europeRatioCases northAmericaRatioCases oceaniaRatioCases southAmericaRatioCases];

allString = ["Africa","Asia","Europe","North America","Oceania","South America"];

%Print results
for i = 1:6
    fprintf('Pixel shade for %s cases :%.f\nPixel shade for %s deaths: %.f\n',allString(i),pixelShadeCases(i),allString(i),pixelShadeDeaths(i))
end
%You should have produced one figure window by the end of this task.
figure(3)
