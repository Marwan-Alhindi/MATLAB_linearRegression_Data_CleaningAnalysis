% Q1b
% Some code may already be provided below
% DO NOT clear, close or clc inside this script
% Apply good programming practices
%
% Name : Mrwan Alhandi
% ID   : 30950708
% Date Modified : 21/05/2022

fprintf('\n Q1b \n\n')
%% b: plotting total daily accumulated cases and daily accumulated deaths vs days tracked
subplot(1,2,1)

uniqueContinent = unique(continent);
days = 1:396;
totalAccumulatedCases = zeros(6,396);
totalAccumulatedDeaths = zeros(6,396);
%using nested loop to calculate the total accumulated days 
for a = 1:6
    for b = 1:396
        %this is a logical that can be used to sum all the cases and deaths
        %for each continent on each day
        z = uniqueContinent(a) == continent & correctedDaysTracked == b;
        %summing all those cases and deaths that are satisfied z condition
        totalAccumulatedCases(a,b) = sum(cases(z));
        totalAccumulatedDeaths(a,b) = sum(deaths(z));
    end
end

%plotting total accumulated cases of each continent
for v = 1:6
    hold on
    plot(days,log(totalAccumulatedCases(v,:)),'-')

end

xlabel('days')
ylabel('Total accumulated cases')
title('Total accumulated cases vs days')
legend('Africa','Asia','Europe','North America','Oceania','South America','Location','best')

 subplot(1,2,2)

 %plotting total accumulated deaths for each continent
for v = 1:6
    hold on
    plot(days,log(totalAccumulatedDeaths(v,:)),'-')
end

xlabel('days')
ylabel('Total accumulated deaths')
title('Total accumulated deaths vs days')
legend('Africa','Asia','Europe','North America','Oceania','South America','Location','best')


%Print results
%You should have produced one figure window by the end of this task.
figure(2)
