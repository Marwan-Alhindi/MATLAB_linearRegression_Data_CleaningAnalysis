% Q2b

% Some code may already be provided below
% DO NOT clear, close or clc inside this script
% Apply good programming practices
%
% Name : Mrwan Alhandi
% ID   : 30950708
% Date Modified : 23/05/2022

fprintf('\n Q2b \n\n')
%%
%Add your code here
all_data = importdata('topspin.txt');
values = all_data.data;
time = values(:,1);
rVelocity = values(:,2);

%plotting raw data
plot(time,rVelocity,'.')
hold on

%using linreg to fit a linear model
[a0,a1,r2] = linreg(time,rVelocity);
y =  a1*time+a0;

%plotting linear model
plot(time,y)

xlabel('time (s)')
ylabel('rotational speed (m/s)')

%linearising data for exponential model
y_exp = log(rVelocity);

%using linreg to get coefficent
[a0exp,a1exp,r2exp] = linreg(time,y_exp);

%getting coefficients for the exponential model
a = exp(a0exp);
b = a1exp;

%plotting exponential model
yfit = @(time) a*exp(b*time);

hold on
plot(time,yfit(time),'-')

%finding initial velocity at t =0 
initialrVelocity = yfit(0);

%using newraph since finding the derivative analytically is simple
f = @(time) a.*exp(b.*time)-3000;
fd = @(time) a.*b.*exp(b.*time);

[x_i,iterations] = newraph(0.4,f,fd,1e-10);

%plotting the root
hold on
plot(x_i,yfit(x_i),'.')
title('rotational speed (rad/s) vs time (s)')
legend('Raw Data','Linear model','Exponential Model','root')

%integrating rotational speed from using range 0.5:2
tFlight = 0.5:0.1:2;
I = zeros(1,length(tFlight));
for i = 1:length(tFlight)
    I(1,i) = comp_trap(yfit,0,tFlight(i),100000000);
end

%plotting the relationship
figure;
plot(tFlight,I)
xlabel('flight time (s)')
ylabel('number of rotations')
title('number of rotations vs flight time (s)')

%Print results
fprintf('Even though the value of r2 is high, linear model is not a good fit for angular velocity.\nThis is because w = (change of angle)/time. If change of angle is constant, as time increases as w decreases.\n')
fprintf('The predicted intial velocity from the exponential model is: %f\n',initialrVelocity)
fprintf('It''s simple to find the derivative analytically for the function w.\n ')
%You should have produced two figure windows by the end of this task.
figure(6)
figure(7)