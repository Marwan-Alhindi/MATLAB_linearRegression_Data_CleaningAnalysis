function [x_i,iterations] = newraph(x_i,f,fd,precision)
% [x_i,iterations] = newraph(x_i,f,fd,precision)
%Written by: Mrwan Alhandi, ID: 30950708
%
%INPUTS:
% - x_i: initial guess of the root of specified function
% - f: specified function
% - fd: the derivative of specified function
% - precision: stopping criteria determined by the user
%OUTPUT:
% - x_i, iterations

iterations = 0;
while abs(f(x_i)) > precision

    iterations = iterations + 1;
    x_i = x_i-f(x_i)/fd(x_i);
end
