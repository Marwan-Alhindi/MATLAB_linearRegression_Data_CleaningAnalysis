% Q2c

% Some code may already be provided below
% DO NOT clear, close or clc inside this script
% Apply good programming practices
%
% Name : Mrwan Alhandi
% ID   : 30950708
% Date Modified : 25 May 2022

fprintf('\n Q2c \n\n')
%%
%Add your code here
%variables
m = 0.577; %kg
p = 1100; %kg/m^3
totalVolume = (4/3)*pi*(0.067/2); %m^3
rubberVolume = (m/p); %m^3
hollowVolume = totalVolume-rubberVolume;
rTotal = 0.067/2; %m
rHollow = ((hollowVolume*3)/(4*pi))^(1/3); %m

%calculating torque for a thick wall hollow rubber sphere
Inertia = ((2*m)/5)*(((rTotal^5)-(rHollow^5))/((rTotal^5)-(rHollow^5))); %kg*m^2
a = 4447.70034850323;
b = -0.752137600390336;
t = 0.5:0.1:2;
%calculating torque for different times
torque = @(t) Inertia.* a.*b.*exp(b.*t); % torque = I*angular acceleration
yfit = @(t) a*exp(b*t);

%the percentage of the ball's initial rotational kinetic energy that has
%been lost
initialKE = 0.5*Inertia*a^2; %at time = 0, w = a
lostKEPercentage = ((initialKE - (0.5.*Inertia.*(yfit(t).^2)))./initialKE).*100;
plot(t,lostKEPercentage)
xlabel('flight time (s)')
ylabel('Percentage lost KE')
title('Percentage lost KE vs flight time (s)')

%Print results
fprintf('The moment of inertia of the tennis ball is: %f\n',Inertia)
%The plot for this section should be on the same axes as Q2b(v)