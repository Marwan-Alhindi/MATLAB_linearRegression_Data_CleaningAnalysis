% Q2a

% Some code may already be provided below
% DO NOT clear, close or clc inside this script
% Apply good programming practices
%
% Name : Mrwan Alhandi
% ID   : 30950708
% Date Modified : 21/05/2022

fprintf('\n Q2a \n\n')
%% a:
%variables
theta = 0:0.01:89;
x = 26.5;
g = 9.81;
y = 0.5;
%plotting the equation found using constant acceleration equations
v = @(theta) sqrt((x^2*g)./(2*cosd(theta).*(y*cosd(theta)+x.*sind(theta))));
plot(v(theta),theta)
xlabel('initial velocity (m/s)')
ylabel('theta (degree)')
title('theta (degree) vs initial velocity (m/s)')

%You should have produced two figure windows by the end of this task.
figure(4)
figure(5)