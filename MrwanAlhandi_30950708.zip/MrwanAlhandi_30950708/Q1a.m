% Q1a
% Some code may already be provided below
% DO NOT clear, close or clc inside this script
% Apply good programming practices
%
% Name :Mrwan Alhandi
% ID   :30950708
% Date Modified : 18/05/2022
fprintf('\n Q1a \n\n')
%% importing data
%COVID DATA:
allDataCOVID = importdata("owid-covid-data_2020-21.csv");
valuesCOVID = allDataCOVID.data;
textCOVID = allDataCOVID.textdata;
location = string(textCOVID(2:end,3));
date = string(textCOVID(2:end,4));
daysTracked = valuesCOVID(:,1);
daysCOVID = valuesCOVID(:,1);
continent = string(textCOVID(2:end,2));
cases = valuesCOVID(:,2);
deaths = valuesCOVID(:,3);

%POPULATION DATA:
allDataPopulation = importdata('Population_data.xlsx');
valuesPopulation = allDataPopulation.data;
textPopulation = allDataPopulation.textdata;
uniqueLocations = string(textPopulation(2:end,2));

%% ai: Updating NaN values to 0
nanDeaths = isnan(deaths);
deaths(nanDeaths) = 0;

nanCases = isnan(cases);
cases(nanCases) = 0;

%% aii: Filtering counteries that does not have 396 enteries with their dates and records

%This loop will calculate the number of days that has been recorded for
%each country
enteriesCounter = zeros(length(uniqueLocations),1);
for i = 1:length(uniqueLocations)
    for j = 1:length(location)
        if uniqueLocations(i) == location(j)
            enteriesCounter(i) = enteriesCounter(i) + 1;
        end
    end
end

%finding countries that their number of days recorded is not 396
filteredCounterLogic = enteriesCounter ~= 396;
filteredCountries = uniqueLocations(filteredCounterLogic);

%This for loop will find the start and end date for those countries that
%does not have 396 days recorded
jump = 1;
counter = 1;
startDate = string(zeros(length(filteredCountries),1));
endDate = string(zeros(length(filteredCountries),1));
records = string(zeros(length(filteredCountries),1));
for k = 1:length(enteriesCounter)
    if enteriesCounter(k) == 396
        jump = jump + 396;
        %Skipping those countries with 396 records by adding 396 to jump
    else
        %If the country does not have 396 the starting date of the country that does not
        % have 396 records index is jump
        startDate(counter) = date(jump);
        %adding the recorded days for the country that does not have 396
        %and then getting the end date
        jump = jump + enteriesCounter(k);
        endDate(counter) = date(jump - 1);
        %extracting the records of those countries that does not have 396
        records(counter) = daysTracked(jump - 1);
        %using counter to allocate the start and end dates for each
        %country
        counter = counter + 1;
    end
end

%concatenating matrix
matrix = [filteredCountries startDate endDate records];

%% aiii: calculating a new corrected days tracked

%re making days tracked with the corrected started day
startingPosition = 397 - str2double(records);
startingPositionCounter = 1;
correctedDaysTracked = zeros(length(daysTracked),1);
counterZ = 0;
for z = 1:length(enteriesCounter)
    if enteriesCounter(z) == 396
        correctedDaysTracked(counterZ+1:counterZ+396) = 1:396;
        counterZ = counterZ + 396;
    else
        %if its not 396, use the value calculated from the startingPosition
        %to fill the matrix
        correctedDaysTracked(counterZ+1:counterZ+enteriesCounter(z)) = startingPosition(startingPositionCounter):396;
        %counterZ is used to allocate correctedDaysTracked
        counterZ = counterZ + enteriesCounter(z);
        %this to jump to the next country starting position
        startingPositionCounter = startingPositionCounter + 1;
    end
end

%% Print results
fprintf('%s\t%s\t%s\t%s\n',matrix') %ii
fprintf('corrected days tracked for Palu is:\n')
fprintf('%d\n',correctedDaysTracked(54690:54699)) %iii

figure(1)
